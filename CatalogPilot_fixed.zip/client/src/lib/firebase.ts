import { initializeApp, getApps, type FirebaseApp } from "firebase/app";
import { 
  getAuth,
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut as fbSignOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  type Auth
} from "firebase/auth";

let app: FirebaseApp | null = null;

function getFirebaseConfig() {
  const apiKey = import.meta.env.VITE_FIREBASE_API_KEY;
  const projectId = import.meta.env.VITE_FIREBASE_PROJECT_ID;
  const appId = import.meta.env.VITE_FIREBASE_APP_ID;
  return { apiKey, projectId, appId };
}

export function getFirebaseApp(): FirebaseApp {
  if (app) return app;
  const cfg = getFirebaseConfig();
  if (!cfg.apiKey || !cfg.projectId || !cfg.appId) {
    throw new Error("FIREBASE_CONFIG_MISSING");
  }
  if (!getApps().length) {
    app = initializeApp({
      apiKey: cfg.apiKey,
      projectId: cfg.projectId,
      appId: cfg.appId,
    });
  }
  return app!;
}

function getAuthSafe(): Auth {
  const a = getAuth(getFirebaseApp());
  return a;
}

export const signInWithGoogle = async () => {
  const provider = new GoogleAuthProvider();
  const auth = getAuthSafe();
  try {
    const result = await signInWithPopup(auth, provider);
    return result.user;
  } catch (error) {
    console.error("Error signing in with Google:", error);
    throw error;
  }
};

export const signInWithEmail = async (email: string, password: string) => {
  const auth = getAuthSafe();
  try {
    const result = await signInWithEmailAndPassword(auth, email, password);
    return result.user;
  } catch (error) {
    console.error("Error signing in with email:", error);
    throw error;
  }
};

export const signUpWithEmail = async (email: string, password: string) => {
  const auth = getAuthSafe();
  try {
    const result = await createUserWithEmailAndPassword(auth, email, password);
    return result.user;
  } catch (error) {
    console.error("Error signing up with email:", error);
    throw error;
  }
};

export const resetPassword = async (email: string) => {
  const auth = getAuthSafe();
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (error) {
    console.error("Error sending password reset email:", error);
    throw error;
  }
};

export const signOutUser = async () => {
  const auth = getAuthSafe();
  try {
    await fbSignOut(auth);
  } catch (error) {
    console.error("Error signing out:", error);
    throw error;
  }
};
