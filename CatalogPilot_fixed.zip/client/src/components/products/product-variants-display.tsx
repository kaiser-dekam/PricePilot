import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { ProductVariant } from "@shared/schema";

interface ProductVariantsDisplayProps {
  productId: string;
  productName: string;
  onVariantUpdate?: (productId: string, variantUpdates: Array<{
    variantId: string;
    variantSku: string;
    optionValues: Array<{
      option_display_name: string;
      label: string;
    }>;
    newRegularPrice?: string;
    newSalePrice?: string;
  }>) => void;
  isEditing?: boolean;
  presetTrigger?: { type: 'removeSalePrices' | 'applyDiscount'; discountPercentage?: string } | null;
}

export default function ProductVariantsDisplay({ 
  productId, 
  productName, 
  onVariantUpdate, 
  isEditing = false,
  presetTrigger
}: ProductVariantsDisplayProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [variantPrices, setVariantPrices] = useState<Record<string, { regular?: string; sale?: string }>>({});

  const { data: variants, isLoading, error } = useQuery<ProductVariant[]>({
    queryKey: [`/api/products/${productId}/variants`],
    enabled: isExpanded, // Only load when expanded
  });

  // Debug logging
  if (isExpanded) {
    console.log(`Product ${productId} variants:`, { variants, isLoading, error });
  }

  // Handle preset applications
  useEffect(() => {
    if (presetTrigger && variants && variants.length > 0) {
      const updatedPrices = { ...variantPrices };
      let hasChanges = false;

      variants.forEach(variant => {
        if (presetTrigger.type === 'removeSalePrices') {
          updatedPrices[variant.id] = {
            ...updatedPrices[variant.id],
            sale: "0.00"
          };
          hasChanges = true;
        } else if (presetTrigger.type === 'applyDiscount' && presetTrigger.discountPercentage) {
          const percentage = parseFloat(presetTrigger.discountPercentage);
          const regularPrice = parseFloat(variant.regularPrice || "0");
          if (percentage > 0 && regularPrice > 0) {
            const salePrice = regularPrice * (1 - percentage / 100);
            updatedPrices[variant.id] = {
              ...updatedPrices[variant.id],
              sale: salePrice.toFixed(2)
            };
            hasChanges = true;
          }
        }
      });

      if (hasChanges) {
        setVariantPrices(updatedPrices);
        
        // Trigger the update callback
        const variantUpdates = variants
          .filter(variant => updatedPrices[variant.id])
          .map(variant => ({
            variantId: variant.id,
            variantSku: variant.variantSku || '',
            optionValues: (variant.optionValues || []).map(opt => ({
              option_display_name: opt.option_display_name,
              label: opt.label
            })),
            newRegularPrice: updatedPrices[variant.id]?.regular,
            newSalePrice: updatedPrices[variant.id]?.sale,
          }))
          .filter(update => update.newRegularPrice || update.newSalePrice);

        onVariantUpdate?.(productId, variantUpdates);
      }
    }
  }, [presetTrigger, variants, productId, onVariantUpdate]);

  const handleVariantPriceChange = (variantId: string, field: 'regular' | 'sale', value: string) => {
    const newPrices = {
      ...variantPrices,
      [variantId]: {
        ...variantPrices[variantId],
        [field]: value
      }
    };
    setVariantPrices(newPrices);

    // Build variant updates array
    const variantUpdates = variants
      ?.filter(variant => newPrices[variant.id])
      ?.map(variant => ({
        variantId: variant.id,
        variantSku: variant.variantSku || '',
        optionValues: (variant.optionValues || []).map(opt => ({
          option_display_name: opt.option_display_name,
          label: opt.label
        })),
        newRegularPrice: newPrices[variant.id]?.regular,
        newSalePrice: newPrices[variant.id]?.sale,
      }))
      ?.filter(update => update.newRegularPrice || update.newSalePrice) || [];

    onVariantUpdate?.(productId, variantUpdates);
  };

  const formatOptionValues = (optionValues: Array<{ option_display_name: string; label: string }>) => {
    return optionValues?.map(opt => `${opt.option_display_name}: ${opt.label}`).join(', ') || 'No options';
  };

  // Always show the component first to check if product has variants
  // Only hide after we've actually checked for variants

  return (
    <div className="border rounded-lg p-3 bg-gray-50">
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center space-x-2 text-sm font-medium mb-2"
      >
        {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        <Package className="w-4 h-4" />
        <span>
          {isLoading ? 'Loading variants...' : 
           variants ? `${variants.length} Variant${variants.length !== 1 ? 's' : ''}` : 
           'Check for variants'}
        </span>
      </Button>

      {isExpanded && (
        <div className="space-y-3">
          {isLoading ? (
            <div className="text-sm text-gray-500">Loading variants...</div>
          ) : error ? (
            <div className="text-sm text-red-500">Error loading variants: {error.message}</div>
          ) : !variants || variants.length === 0 ? (
            <div className="text-sm text-gray-500">No variants found for this product</div>
          ) : (
            variants.map((variant) => (
              <div key={variant.id} className="border rounded p-3 bg-white">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <div className="text-sm font-medium text-gray-900 mb-1">
                      {variant.variantSku || `Variant ${variant.id}`}
                    </div>
                    <div className="text-xs text-gray-500 mb-2">
                      {formatOptionValues(variant.optionValues || [])}
                    </div>
                    <div className="flex space-x-2">
                      <Badge variant="outline" className="text-xs">
                        Regular: ${variant.regularPrice || '0'}
                      </Badge>
                      {variant.salePrice && (
                        <Badge variant="secondary" className="text-xs">
                          Sale: ${variant.salePrice}
                        </Badge>
                      )}
                    </div>
                  </div>

                  {isEditing && (
                    <div className="space-y-2">
                      <div>
                        <Label htmlFor={`regular-${variant.id}`} className="text-xs">
                          New Regular Price
                        </Label>
                        <Input
                          id={`regular-${variant.id}`}
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder={variant.regularPrice || '0'}
                          value={variantPrices[variant.id]?.regular || ''}
                          onChange={(e) => handleVariantPriceChange(variant.id, 'regular', e.target.value)}
                          className="text-sm"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`sale-${variant.id}`} className="text-xs">
                          New Sale Price
                        </Label>
                        <Input
                          id={`sale-${variant.id}`}
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder={variant.salePrice || '0'}
                          value={variantPrices[variant.id]?.sale || ''}
                          onChange={(e) => handleVariantPriceChange(variant.id, 'sale', e.target.value)}
                          className="text-sm"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}