import { useState, useEffect } from 'react';
import { onAuthStateChanged, User as FirebaseUser, getAuth } from 'firebase/auth';
import { getFirebaseApp } from '@/lib/firebase';
import { useQuery } from '@tanstack/react-query';

export function useAuth() {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [isFirebaseLoading, setIsFirebaseLoading] = useState(true);

  // Listen to Firebase auth state changes
  useEffect(() => {
    let authInst;
    try { authInst = getAuth(getFirebaseApp()); } catch (e) { console.warn('Firebase not configured:', e); setIsFirebaseLoading(false); return; }
    const unsubscribe = onAuthStateChanged(authInst, (user) => {
      console.log("Firebase auth state changed:", !!user);
      setFirebaseUser(user);
      setIsFirebaseLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Get user data from backend when Firebase user exists
  const { data: backendUser, isLoading: isBackendLoading, error: backendError } = useQuery({
    queryKey: ['/api/auth/firebase-user'],
    enabled: !!firebaseUser && !isFirebaseLoading,
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
  });

  const isLoading = isFirebaseLoading || (firebaseUser && isBackendLoading);
  const isAuthenticated = !!firebaseUser && !!backendUser;

  // Debug logging
  useEffect(() => {
    console.log("Auth hook state:", {
      firebaseUser: !!firebaseUser,
      backendUser: !!backendUser,
      isFirebaseLoading,
      isBackendLoading,
      isLoading,
      isAuthenticated,
      backendError: backendError?.message
    });
  }, [firebaseUser, backendUser, isFirebaseLoading, isBackendLoading, isLoading, isAuthenticated, backendError]);

  return {
    user: backendUser,
    firebaseUser,
    isLoading,
    isAuthenticated,
    error: backendError,
  };
}