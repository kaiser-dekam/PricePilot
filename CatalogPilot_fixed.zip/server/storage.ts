import { 
  type ApiSettings, 
  type InsertApiSettings, 
  type Product, 
  type InsertProduct, 
  type ProductVariant, 
  type InsertProductVariant, 
  type WorkOrder, 
  type InsertWorkOrder, 
  type User, 
  type UpsertUser,
  type Company,
  type InsertCompany,
  type CompanyInvitation,
  type InsertCompanyInvitation,
  apiSettings, 
  products, 
  productVariants, 
  workOrders, 
  users,
  companies,
  companyInvitations
} from "@shared/schema";
import { randomUUID } from "crypto";
import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, ilike, and, desc, count, or } from "drizzle-orm";

export interface IStorage {
  // Company operations
  getCompany(id: string): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;
  updateCompanySubscription(id: string, updates: Partial<Company>): Promise<Company | undefined>;
  
  // User operations  
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getCompanyUsers(companyId: string): Promise<User[]>;
  
  // Company invitations
  createInvitation(invitation: InsertCompanyInvitation): Promise<CompanyInvitation>;
  getInvitation(token: string): Promise<CompanyInvitation | undefined>;
  acceptInvitation(token: string, userId: string): Promise<boolean>;
  getCompanyInvitations(companyId: string): Promise<CompanyInvitation[]>;
  
  // API Settings
  getApiSettings(companyId: string): Promise<ApiSettings | undefined>;
  saveApiSettings(companyId: string, settings: InsertApiSettings): Promise<ApiSettings>;
  updateApiSettingsLastSync(companyId: string, lastSyncAt: Date): Promise<void>;
  
  // Products
  getProducts(companyId: string, filters?: { category?: string; search?: string; page?: number; limit?: number }): Promise<{ products: Product[]; total: number }>;
  getProduct(companyId: string, id: string): Promise<Product | undefined>;
  createProduct(companyId: string, product: InsertProduct & { id: string }): Promise<Product>;
  updateProduct(companyId: string, id: string, updates: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(companyId: string, id: string): Promise<boolean>;
  clearCompanyProducts(companyId: string): Promise<void>;
  
  // Product Variants
  getProductVariants(companyId: string, productId: string): Promise<ProductVariant[]>;
  createProductVariant(companyId: string, variant: InsertProductVariant & { id: string; productId: string }): Promise<ProductVariant>;
  updateProductVariant(companyId: string, id: string, updates: Partial<ProductVariant>): Promise<ProductVariant | undefined>;
  deleteProductVariant(companyId: string, id: string): Promise<boolean>;
  clearProductVariants(companyId: string, productId: string): Promise<void>;
  
  // Work Orders
  getWorkOrders(companyId: string, filters?: { archived?: boolean }): Promise<WorkOrder[]>;
  getWorkOrder(companyId: string, id: string): Promise<WorkOrder | undefined>;
  createWorkOrder(companyId: string, createdBy: string, workOrder: InsertWorkOrder): Promise<WorkOrder>;
  updateWorkOrder(companyId: string, id: string, updates: Partial<WorkOrder>): Promise<WorkOrder | undefined>;
  deleteWorkOrder(companyId: string, id: string): Promise<boolean>;
  getPendingWorkOrders(): Promise<WorkOrder[]>;
}

// Database storage implementation
export class DbStorage implements IStorage {
  private db;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is required");
    }
    const sql = neon(process.env.DATABASE_URL);
    this.db = drizzle(sql);
  }

  // Company operations
  async getCompany(id: string): Promise<Company | undefined> {
    const result = await this.db.select().from(companies).where(eq(companies.id, id));
    return result[0];
  }

  async createCompany(companyData: InsertCompany): Promise<Company> {
    const result = await this.db
      .insert(companies)
      .values(companyData)
      .returning();
    return result[0];
  }

  async updateCompanySubscription(id: string, updates: Partial<Company>): Promise<Company | undefined> {
    const result = await this.db
      .update(companies)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(companies.id, id))
      .returning();
    return result[0];
  }

  // User operations  
  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const result = await this.db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          companyId: userData.companyId,
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          role: userData.role,
          isActive: userData.isActive,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result[0];
  }

  async getCompanyUsers(companyId: string): Promise<User[]> {
    return await this.db
      .select()
      .from(users)
      .where(and(eq(users.companyId, companyId), eq(users.isActive, true)));
  }

  // Company invitations
  async createInvitation(invitationData: InsertCompanyInvitation): Promise<CompanyInvitation> {
    const result = await this.db
      .insert(companyInvitations)
      .values(invitationData)
      .returning();
    return result[0];
  }

  async getInvitation(token: string): Promise<CompanyInvitation | undefined> {
    const result = await this.db
      .select()
      .from(companyInvitations)
      .where(eq(companyInvitations.token, token));
    return result[0];
  }

  async acceptInvitation(token: string, userId: string): Promise<boolean> {
    const invitation = await this.getInvitation(token);
    if (!invitation || invitation.acceptedAt || invitation.expiresAt < new Date()) {
      return false;
    }

    // Update user's company and role
    await this.db
      .update(users)
      .set({ 
        companyId: invitation.companyId, 
        role: invitation.role,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId));

    // Mark invitation as accepted
    await this.db
      .update(companyInvitations)
      .set({ acceptedAt: new Date() })
      .where(eq(companyInvitations.token, token));

    return true;
  }

  async getCompanyInvitations(companyId: string): Promise<CompanyInvitation[]> {
    return await this.db
      .select()
      .from(companyInvitations)
      .where(eq(companyInvitations.companyId, companyId))
      .orderBy(desc(companyInvitations.createdAt));
  }

  // API Settings
  async getApiSettings(companyId: string): Promise<ApiSettings | undefined> {
    const result = await this.db.select().from(apiSettings).where(eq(apiSettings.companyId, companyId)).limit(1);
    return result[0];
  }

  async saveApiSettings(companyId: string, settings: InsertApiSettings): Promise<ApiSettings> {
    // Delete existing settings for this company and insert new ones
    await this.db.delete(apiSettings).where(eq(apiSettings.companyId, companyId));
    const result = await this.db.insert(apiSettings).values({
      ...settings,
      companyId,
    }).returning();
    return result[0];
  }

  async updateApiSettingsLastSync(companyId: string, lastSyncAt: Date): Promise<void> {
    await this.db
      .update(apiSettings)
      .set({ lastSyncAt })
      .where(eq(apiSettings.companyId, companyId));
  }

  // Products
  async getProducts(companyId: string, filters?: { category?: string; search?: string; page?: number; limit?: number }): Promise<{ products: Product[]; total: number }> {
    console.log(`Getting products for company: ${companyId}`);
    const page = filters?.page || 1;
    const limit = filters?.limit || 50;
    const offset = (page - 1) * limit;

    // Build where conditions
    const conditions = [eq(products.companyId, companyId)];
    if (filters?.category && filters.category !== "all") {
      conditions.push(eq(products.category, filters.category));
    }
    if (filters?.search) {
      conditions.push(
        or(
          ilike(products.name, `%${filters.search}%`),
          ilike(products.sku, `%${filters.search}%`),
          eq(products.id, filters.search)
        )!
      );
    }

    const whereClause = and(...conditions);
    
    // First, let's check total products in database for this company
    const allProductsCount = await this.db
      .select({ count: count() })
      .from(products)
      .where(eq(products.companyId, companyId));
    console.log(`Total products in DB for company ${companyId}: ${allProductsCount[0]?.count || 0}`);
    
    // Get products with pagination
    const productResults = await this.db
      .select()
      .from(products)
      .where(whereClause)
      .orderBy(desc(products.lastUpdated))
      .limit(limit)
      .offset(offset);

    // Get total count
    const countResult = await this.db
      .select({ count: count() })
      .from(products)
      .where(whereClause);

    console.log(`Query returned ${productResults.length} products, total count: ${countResult[0]?.count || 0}`);
    
    return {
      products: productResults,
      total: countResult[0]?.count || 0,
    };
  }

  async getProduct(companyId: string, id: string): Promise<Product | undefined> {
    const result = await this.db
      .select()
      .from(products)
      .where(and(eq(products.companyId, companyId), eq(products.id, id)));
    return result[0];
  }

  async createProduct(companyId: string, product: InsertProduct & { id: string }): Promise<Product> {
    try {
      console.log(`Creating/updating product ${product.id}: ${product.name}`);
      const result = await this.db
        .insert(products)
        .values({ ...product, companyId })
        .onConflictDoUpdate({
          target: products.id,
          set: {
            name: product.name,
            sku: product.sku,
            description: product.description,
            category: product.category,
            regularPrice: product.regularPrice,
            salePrice: product.salePrice,
            stock: product.stock,
            weight: product.weight,
            status: product.status,
            lastUpdated: new Date()
          }
        })
        .returning();
      console.log(`Product ${product.id} saved successfully`);
      return result[0];
    } catch (error) {
      console.error(`Error saving product ${product.id}:`, error);
      throw error;
    }
  }

  async updateProduct(companyId: string, id: string, updates: Partial<Product>): Promise<Product | undefined> {
    const result = await this.db
      .update(products)
      .set(updates)
      .where(and(eq(products.companyId, companyId), eq(products.id, id)))
      .returning();
    return result[0];
  }

  async deleteProduct(companyId: string, id: string): Promise<boolean> {
    const result = await this.db
      .delete(products)
      .where(and(eq(products.companyId, companyId), eq(products.id, id)))
      .returning();
    return result.length > 0;
  }

  async clearCompanyProducts(companyId: string): Promise<void> {
    console.log(`Clearing products for company ${companyId}...`);
    
    try {
      // Delete product variants first due to foreign key constraint
      const variantsDeleted = await this.db.delete(productVariants).where(eq(productVariants.companyId, companyId)).returning({ id: productVariants.id });
      console.log(`Deleted ${variantsDeleted.length} product variants`);
      
      // Then delete products
      const productsDeleted = await this.db.delete(products).where(eq(products.companyId, companyId)).returning({ id: products.id });
      console.log(`Deleted ${productsDeleted.length} products`);
      
      // Verify products are cleared
      const remainingCount = await this.db
        .select({ count: count() })
        .from(products)
        .where(eq(products.companyId, companyId));
      
      if (remainingCount[0]?.count > 0) {
        throw new Error(`Failed to clear all products. ${remainingCount[0].count} products remain.`);
      }
      
      console.log(`Successfully cleared all company products`);
    } catch (error) {
      console.error(`Error clearing company products:`, error);
      throw error;
    }
  }

  // Product Variants
  async getProductVariants(companyId: string, productId: string): Promise<ProductVariant[]> {
    return await this.db
      .select()
      .from(productVariants)
      .where(and(eq(productVariants.companyId, companyId), eq(productVariants.productId, productId)));
  }

  async createProductVariant(companyId: string, variant: InsertProductVariant & { id: string; productId: string }): Promise<ProductVariant> {
    try {
      console.log(`Creating/updating variant ${variant.id} for product ${variant.productId}`);
      const result = await this.db
        .insert(productVariants)
        .values({
          id: variant.id,
          companyId,
          productId: variant.productId,
          variantSku: variant.variantSku,
          optionValues: variant.optionValues || [],
          regularPrice: variant.regularPrice,
          salePrice: variant.salePrice,
          calculatedPrice: variant.calculatedPrice,
          stock: variant.stock
        } as any)
        .onConflictDoUpdate({
          target: productVariants.id,
          set: {
            productId: variant.productId,
            variantSku: variant.variantSku,
            optionValues: variant.optionValues || [],
            regularPrice: variant.regularPrice,
            salePrice: variant.salePrice,
            calculatedPrice: variant.calculatedPrice,
            stock: variant.stock
          }
        })
        .returning();
      console.log(`Variant ${variant.id} saved successfully`);
      return result[0];
    } catch (error) {
      console.error(`Error saving variant ${variant.id}:`, error);
      throw error;
    }
  }

  async updateProductVariant(companyId: string, id: string, updates: Partial<ProductVariant>): Promise<ProductVariant | undefined> {
    const result = await this.db
      .update(productVariants)
      .set(updates)
      .where(and(eq(productVariants.companyId, companyId), eq(productVariants.id, id)))
      .returning();
    return result[0];
  }

  async deleteProductVariant(companyId: string, id: string): Promise<boolean> {
    const result = await this.db
      .delete(productVariants)
      .where(and(eq(productVariants.companyId, companyId), eq(productVariants.id, id)))
      .returning();
    return result.length > 0;
  }

  async clearProductVariants(companyId: string, productId: string): Promise<void> {
    await this.db
      .delete(productVariants)
      .where(and(eq(productVariants.companyId, companyId), eq(productVariants.productId, productId)));
  }

  // Work Orders
  async getWorkOrders(companyId: string, filters?: { archived?: boolean }): Promise<WorkOrder[]> {
    const conditions = [eq(workOrders.companyId, companyId)];
    
    if (filters?.archived !== undefined) {
      conditions.push(eq(workOrders.archived, filters.archived));
    }

    return await this.db
      .select()
      .from(workOrders)
      .where(and(...conditions))
      .orderBy(desc(workOrders.createdAt));
  }

  async getWorkOrder(companyId: string, id: string): Promise<WorkOrder | undefined> {
    const result = await this.db
      .select()
      .from(workOrders)
      .where(and(eq(workOrders.companyId, companyId), eq(workOrders.id, id)));
    return result[0];
  }

  async createWorkOrder(companyId: string, createdBy: string, workOrder: InsertWorkOrder): Promise<WorkOrder> {
    const result = await this.db
      .insert(workOrders)
      .values({
        title: workOrder.title,
        companyId, 
        createdBy,
        productUpdates: workOrder.productUpdates || [],
        originalPrices: [],
        scheduledAt: workOrder.scheduledAt,
        executeImmediately: workOrder.executeImmediately || false,
        status: 'pending',
        archived: false
      } as any)
      .returning();
    return result[0];
  }

  async updateWorkOrder(companyId: string, id: string, updates: Partial<WorkOrder>): Promise<WorkOrder | undefined> {
    const result = await this.db
      .update(workOrders)
      .set(updates)
      .where(and(eq(workOrders.companyId, companyId), eq(workOrders.id, id)))
      .returning();
    return result[0];
  }

  async deleteWorkOrder(companyId: string, id: string): Promise<boolean> {
    const result = await this.db
      .delete(workOrders)
      .where(and(eq(workOrders.companyId, companyId), eq(workOrders.id, id)))
      .returning();
    return result.length > 0;
  }

  async getPendingWorkOrders(): Promise<WorkOrder[]> {
    return await this.db
      .select()
      .from(workOrders)
      .where(eq(workOrders.status, "pending"));
  }
}

export const storage: IStorage = new DbStorage();